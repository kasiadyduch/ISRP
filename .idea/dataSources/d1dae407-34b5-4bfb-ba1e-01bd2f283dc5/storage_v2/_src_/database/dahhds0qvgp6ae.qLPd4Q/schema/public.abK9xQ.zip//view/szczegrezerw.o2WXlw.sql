CREATE VIEW szczegrezerw AS
  SELECT r.id_rezerwacji,
    l.imie AS imiel,
    l.nazwisko AS nazwiskol,
    po.opis,
    r.data,
    r.godzina,
    pa.imie,
    pa.nazwisko,
    pa.pesel,
    pa.email,
    pa.nr_telefonu,
    r.id_poradni
   FROM rezerwacje r,
    lekarze l,
    poradnie po,
    pacjenci pa
  WHERE ((r.id_lekarza = l.id_lekarza) AND (r.id_pacjenta = pa.id_pacjenta) AND (r.id_poradni = po.id_poradni));

